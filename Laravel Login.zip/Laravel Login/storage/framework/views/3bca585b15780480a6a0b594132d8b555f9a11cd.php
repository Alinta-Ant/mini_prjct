
<?php $__env->startSection("content"); ?>
<div class="container">
<div class="row">

<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
<table class="table">
<tr>
    <th>MODEL</th>
    <th>NETWORK</th>
    <th>LAUNCH</th>
    <th>BODY</th>
    <th>DISPLAY</th>
    <th>PLATFORM</th>
    <th>MEMORY</th>
    <th>BATTERY</th>
    <th>MAIN CAMERA</th>
    <th>SELFIE CAMERA</th>
    <th>FEATURES</th>
    <th>PRICE</th>
</tr>
<?php $__currentLoopData = $mobiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($mobile->mmodel); ?></td>
    <td><?php echo e($mobile->mnetwork); ?></td>
    <td><?php echo e($mobile->mlaunch); ?></td>
    <td><?php echo e($mobile->mbody); ?></td>
    <td><?php echo e($mobile->mdisplay); ?></td>
    <td><?php echo e($mobile->mplatform); ?></td>
    <td><?php echo e($mobile->mmemory); ?></td>
    <td><?php echo e($mobile->mbattery); ?></td>
    <td><?php echo e($mobile->mmaincamera); ?></td>
    <td><?php echo e($mobile->mselfiecamera); ?></td>
    <td><?php echo e($mobile->mfeatures); ?></td>
    <td><?php echo e($mobile->mprice); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
</div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravelproject\mobileandlaptop-app\resources\views/viewallmobiles.blade.php ENDPATH**/ ?>