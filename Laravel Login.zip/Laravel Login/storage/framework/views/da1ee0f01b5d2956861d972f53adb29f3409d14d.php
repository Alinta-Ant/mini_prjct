

<?php $__env->startSection("content"); ?>
<div class="bg-image"
  style="
    background-image: url('https://photos.infinum.com/store/7c4406acb38cc9a53f16ec3bb98cc676.jpg');
    height: 200vh; "
>
<div class="container" >
  <div  class="row"><h1  style="color :white;"><br><br>FANTASY<br><br>   </h1> <br><br></div>
  <div  class="row">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<div class="container">
    <div class="row clearfix">
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://cdn.pastemagazine.com/www/articles/assets_c/2018/12/STL090091-thumb-500x769-1045732.jpeg" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Simple Black Clock</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$16.00</li>
                            <li class="new_price">$13.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShFpQZrpwWVqZeOZesN_xfoHSAnxaAs0q9--AjT-ONLsVqHAT7-AmbxYKCdZLzoF7r8UU&usqp=CAU" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Simple Black Clock</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$12.00</li>
                            <li class="new_price">$11.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQP2bUO4s_rUYTo60Zof_2e55EFkyyZqmcSzZBU32D5brtE-FTeyh5TtuxM6kdTQDMtWqw&usqp=CAU  " style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Brone Candle</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$23.00</li>
                            <li class="new_price">$17.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://i2.wp.com/aliendimensions.com/wp-content/uploads/2020/02/Fantasy-Short-Stories-Book-Four-cover-updated-scaled.jpg?fit=679%2C1024&ssl=1" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Simple Black Clock</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$16.00</li>
                            <li class="new_price">$10.00</li>
                        </ul>
                    </div>
                    
                </div>
            </div>
        </div>
        <div><br><br><br></div>
        <div class="col-lg-3 col-md-4 col-sm-12">
        
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRVXPV9nrLeeQmSearwEv2jDH5W_gHhWR-9A&usqp=CAU" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Brone Lamp Glasses</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$18.00</li>
                            <li class="new_price">$15.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVfAe0jAXeusOGU7ASjg7ArTVJ9ExgACf4tkNZio5FvdoEXJP1eUE3GVEhN_VE91DwBqI&usqp=CAU" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Unero Small Bag</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$21.00</li>
                            <li class="new_price">$17.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTb-8YH-Af1ruY_MITj_pYhu82CmuVC0ZU3dKBBfB3sbnEXJRK7sz_0nSZiUMvNJvof_aU&usqp=CAU" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Unero Round lass</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$16.00</li>
                            <li class="new_price">$10.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyJoEQINAhnT-Y8B1ciWm4ajibKRHmVnK3wMfOpGHH2Bimrq5xtll951mJUrC6HaHYF4g&usqp=CAU" style=width:400px;height:400px; alt="Product" class="img-fluid">
                        <div class="hover">
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-plus"></i></a>
                            <a href="javascript:void(0);" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>
                        </div>
                    </div>
                    <div class="product_details">
                        <h5><a href="ec-product-detail.html">Wood Simple Clock</a></h5>
                        <ul class="product_price list-unstyled">
                            <li class="old_price">$16.00</li>
                            <li class="new_price">$10.00</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div><br><br><br></div>
       
                </div>
            </div>
        </div>
    </div>
</div>




<form  action="/loginaction" method="post" >

<?php echo e(csrf_field()); ?>



</form>
</div>
</div> 
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MJ\Downloads\Laravel Login (2)\Laravel Login\resources\views/fantasy.blade.php ENDPATH**/ ?>