

<?php $__env->startSection("content"); ?>

<div class="bg-image"
  style="
    background-image: url('https://d341ezm4iqaae0.cloudfront.net/assets/2020/06/30160014/librarian-scaled.jpg');
    height: 200vh; "
>

 


<form  action="/loginaction" method="post" >

<?php echo e(csrf_field()); ?>



</form>
</div>
</div> 
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme2", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\alinta\Laravel Login\resources\views/admin/adminhome.blade.php ENDPATH**/ ?>