

<?php $__env->startSection("content"); ?>
<div class="bg-image"
  style="
    background-image: url('https://photos.infinum.com/store/7c4406acb38cc9a53f16ec3bb98cc676.jpg');
    height: 200vh; "
>
<div class="container" >
  <div  class="row"><h1  style="color :white;"><br><br>BOOKS<br><br>   </h1> <br><br></div>
  <div  class="row">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<div class="container">
    <div class="row clearfix">
        <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                    <a href="/horror">   <img src="https://i2.wp.com/comicbookinvest.com/wp-content/uploads/2020/07/37-Horrific-3.jpg?ssl=1" alt="Product" class="img-fluid"></a>   
                    </div>                  
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                    <a href="/superhero">     <img src="https://upload.wikimedia.org/wikipedia/commons/1/1e/Front_cover%2C_%22Wow_Comics%22_no._38_%28art_by_Jack_Binder%29.jpg" alt="Product" class="img-fluid"></a>
                       
                    </div>
                   
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                    <a href="/fiction">    <img src="https://cdn3.vectorstock.com/i/1000x1000/97/07/comic-scifi-book-cover-template-vector-18419707.jpg  " alt="Product" class="img-fluid"></a>
                        
                    </div>
                   
                </div>
            </div>
        </div>
        
        <div><br><br><br></div>
        <div class="col-lg-4 col-md-4 col-sm-12">
        
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                    <a href="/fantasy">    <img src="https://i.pinimg.com/originals/26/f6/e6/26f6e6fbf503174ed21b1e85d88497ba.jpg" alt="Product" class="img-fluid"></a>
                      
                    </div>
                  
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                    <a href="/life">      <img src="https://www.europecomics.com/assets/uploads/2018/05/CV1_BEAUX-ETES-EUC_01-1-e1527599698533.jpg" alt="Product" class="img-fluid">  </a>
                    </div>
                 
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                    <a href="/login">   <img src="https://humoropedia.com/wp-content/uploads/2014/07/All-Humor-Comics-f-1.jpg" alt="Product" class="img-fluid"></a>
                       
                    </div>
                    
                    
                </div>
            </div>
        </div>
        <div><br><br><br></div>
       
                </div>
            </div>
        </div>
    </div>
</div>




<form  action="/loginaction" method="post" >

<?php echo e(csrf_field()); ?>



</form>
</div>
</div> 
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MJ\Downloads\Laravel Login (2)\Laravel Login\resources\views/home.blade.php ENDPATH**/ ?>