

<?php $__env->startSection("content"); ?>
<div class="bg-image"
  style="
    background-image: url('https://th.bing.com/th/id/OIP.QAn3pzSP8Bl4dDDgH_SXTQHaH9?pid=ImgDet&rs=1');
    height: 100vh; "
>
<div class="container" 
  ><div  class="row">

<div class="col col-12 col-sm-3 col-md-3 col-lg-3 col-xl-3"></div>
<div  class="col col-12 col-sm-5 col-md-5 col-lg-5 col-xl-5" >


<form  action="/loginaction" method="post" >

<?php echo e(csrf_field()); ?>

<br><br><br><br>
<div class="row"> <br><br></div>
<div class="row" class="bg-image"
  style="
    background-image: url('https://cdn.wallpapersafari.com/50/30/6MTewx.png');
    height: 400px;  "  class="table-table-borderless"  >
<table >
 <tr>
 <h1 style="color :white;">  CONTACT</h1>
     <td style="color :white;">FOR HELPLINE: </td>
     <td style="color :white;">
     0484-23645563<br>
     </td>
 </tr>
   <tr>
     <td style="color :white;">EMAIL: </td>
     <td style="color :white;"> comicbooks@gmail.com<br>
</td>
 </tr>
</table>
</form>
</div>
</div> 
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MJ\Downloads\Laravel Login (2)\Laravel Login\resources\views/help.blade.php ENDPATH**/ ?>