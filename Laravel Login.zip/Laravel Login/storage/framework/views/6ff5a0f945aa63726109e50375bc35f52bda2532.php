
<?php $__env->startSection("content"); ?>
<div class="container">
<br><br><br><br><br><br><br><br>
<p><h5><center>E-commerce is revolutionizing the way we all shop in India. Why do you want to hop from one store to another in search of the latest phone when you can find it on the Internet in a single click? Not only mobiles, our website houses everything you can possibly imagine, from trending electronics like laptops, tablets, smartphones, we got them all covered. You name it, and you can stay assured about finding them all here. For those of you with erratic working hours, Mobile&Laptop is your best bet. Shop in your PJs, at night or in the wee hours of the morning. Across India, there are thousands of sellers, authors and businesses using Mobile&Laptop products and services to reach new customers, build and grow their businesses. A snapshot of how we are impacting lives in India.</h5></p>
<p><h5><center>THIS IS E-COMMERCE, WE NEVER SHUT DOWN !!</h5></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravelproject\mobileandlaptop-app\resources\views/aboutus.blade.php ENDPATH**/ ?>