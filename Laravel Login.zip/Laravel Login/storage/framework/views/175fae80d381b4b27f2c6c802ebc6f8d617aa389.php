
<?php $__env->startSection("content"); ?>
<div class="bg-image"
  style="
    background-image: url('https://data.whicdn.com/images/326399109/original.jpg');
    height: 100vh; "
><br><br><br><br><div class="container" style="background-color: #EBEBEB;">
<div class="container">
<div class="row">
<div class="col col-12 col-sm-5 col-md-5 col-lg-5 col-xl-5">
<br>
<br>
<br>
<br>
<br>
<table class="table table table-dark">
<tr><th scope="row">Category Id</th>
    <th scope="row">Category Name</th>
   </tr>
    
<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr class="table-primary">
   
    <td><?php echo e($categorys->CategoryId); ?></td>
  
    <td><?php echo e($categorys->CategoryName); ?></td>
  
   
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<div class="col col-12 col-sm-2 col-md-2 col-lg-2 col-xl-2">
</div>
<div class="col col-12 col-sm-5 col-md-5 col-lg-5 col-xl-5">
<form action="/categoryread" method="post">
<?php echo e(csrf_field()); ?>

<?php if(Session::get('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
     <?php endif; ?>
    <?php if(Session::get('fail')): ?>
            <div class="alert alert-danger">
            <?php echo e(Session::get('fail')); ?>

            </div>
    <?php endif; ?>
<table class="table table-borderless">
<tr>
<br>
<br>
<br>
<br>
<center><h2 style="color:black"><b>ADD CATEGORY</b></h2></center>
<br>
    <td style="color:black"><b>CATEGORY ID</b></td>
    <td><input type="text" value="<?php echo e(old('CategoryId')); ?>" class="form-control" name="CategoryId" required>
    <span class="text-danger"><?php $__errorArgs = ['CategoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>
</tr>
<tr>
    <td style="color:black"><b>CATEGORY NAME</b></td>
    <td><input type="text" value="<?php echo e(old('CategoryName')); ?>" class="form-control" name="CategoryName" required> 
    <span class="text-danger"><?php $__errorArgs = ['CategoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>
</tr>
<tr>
<tr>
    <td></td>
</tr>
    <td></td>
    <td><button class="btn btn-success">Add</button></td>
</tr>
</table>

</form>
</div>


</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("theme2", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravelproject\Laravel Login (2)\Laravel Login\resources\views/addcategory.blade.php ENDPATH**/ ?>