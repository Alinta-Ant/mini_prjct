
<?php $__env->startSection("content"); ?>
<div class="bg-image"
  style="
    background-image: url('https://www.desktopbackground.org/download/4096x2160/2011/06/04/213967_yellow-wallpaper-hd-wsp015_5184x3456_h.jpg');
    height: 200vh; "
>

<br>
<div class="container">
<div class="row">
<div class="col col-12 col-sm-2 col-md-2 col-lg-2 col-xl-2 col-xxl-2 ">
 </div>
 <div class="col col-12 col-sm-8 col-md-8 col-lg-8 col-xl-8 col-xxl-8 ">
 <br><br>
 <table class="table">
 
<tr><th scope="row">Comicbook Category</th>
    <th scope="row">Comicbook Id</th>
    <th scope="row">Comicbook Name</th>
    <th scope="row">Comicbook Price</th>
    <th scope="row">Comicbook Description</th>
    <th scope="row"><center>image</center></th>
    <th>#</th>
    </tr>
<form action="update" method="post" >
<?php echo csrf_field(); ?>    
<?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr class="table-primary">
   
    <td > <input name="ComicbookCategory" type="text" class="form-control" value="<?php echo e($prods->ComicbookCategory); ?>">  <span class="text-danger"><?php $__errorArgs = ['ComicbookCategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>

    <td><input name="ComicbookId" type="text" class="form-control" value="<?php echo e($prods->ComicbookId); ?>"> <span class="text-danger"><?php $__errorArgs = ['ComicbookId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>
    <td><input name="ComicbookName" type="text" class="form-control" value="<?php echo e($prods->ComicbookName); ?>"> <span class="text-danger"><?php $__errorArgs = ['ComicbookName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>
    <td><input name="ComicbookPrice" type="text" class="form-control" value="<?php echo e($prods->ComicbookPrice); ?>"> <span class="text-danger"><?php $__errorArgs = ['ComicbookPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>
    <td><input name="ComicbookDescription" type="text" class="form-control" value="<?php echo e($prods->ComicbookDescription); ?>"> <span class="text-danger"><?php $__errorArgs = ['ComicbookDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  </span></td>
    
    <td><img width="150" height="100" src="<?php echo e(URL ::asset('assets/project_img/'.$prods->pimage)); ?>"></td>

   <td><button class="btn btn-primary" type="submit" >SAVE</button><input type="hidden" name="id"  value="<?php echo e($prods->id); ?>"/></td>
   
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form> 
</table>
</div>
 <div class="col col-12 col-sm-2 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>       
</body>
</html>
<?php echo $__env->make("theme2", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravelproject\Laravel Login (2)\Laravel Login\resources\views/editview.blade.php ENDPATH**/ ?>