
<?php $__env->startSection("content"); ?>
<br>
<h1><b>  Mobile&Laptop Help Center | 24x7 Customer Care Support</h1>
<div class="container">
<br><br><br><br><br><br>
<p><h1><center><b>Headquarters</h1></p>
<p><h5><center>Rajagiri College of Social Sciences (Autonomous),<br>
Rajagiri P.O,<br>
Kalamassery, Cochin - 683 104,<br>
Kerala, India.<br><br> Email: admin@rajagiri.edu (Office)<br>
        rcssadmission@rajagiri.edu (Admissions)<br><br>Contact No : +91 484 - 2911111 / 2911507 <br>
 +91 484 - 2532862</h5></p>
 <br><br>
 <p><h1><center><b>Technical Support</h1></p>
<p><h5><center>Rajagiri College of Social Sciences<br>
(Autonomous),
Rajagiri Valley P. O,<br>
Kakkanad, Kochi - 682 039,<br>
Kerala, India.<br><br>

 Email: rsom@rajagiri.edu (Office)<br>
        admission@rajagiri.edu (Admissions)<br><br>
 Contact: +91 - 484 - 2660555 / 2660609<br>
+91 484 - 2426578</h5></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravelproject\mobileandlaptop-app\resources\views/contactus.blade.php ENDPATH**/ ?>