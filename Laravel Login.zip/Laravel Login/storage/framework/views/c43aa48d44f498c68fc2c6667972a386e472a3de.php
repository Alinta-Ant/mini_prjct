

<?php $__env->startSection("content"); ?>
<div class="bg-image"
  style="
    background-image: url('https://photos.infinum.com/store/7c4406acb38cc9a53f16ec3bb98cc676.jpg');
    height: 200vh; "
>

 


<form  action="/loginaction" method="post" >

<?php echo e(csrf_field()); ?>



</form>
</div>
</div> 
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme2", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravelproject\Laravel Login (2)\Laravel Login\resources\views/adminhome.blade.php ENDPATH**/ ?>